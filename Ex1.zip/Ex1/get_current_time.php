<?php
echo time();
?>